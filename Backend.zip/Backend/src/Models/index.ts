// imports
import mongoose from "mongoose";
import { adminsSchema } from "./Admins";
import { quizsSchema } from "./Quizs";

// exports
export const Admins = mongoose.model("Admins", adminsSchema);
export const Quizs = mongoose.model("Quizs", quizsSchema);
