
// define function that check if
// the obj is of person details or
// not
export function isPerson(obj: any) {
  if (typeof obj !== 'object' || obj === null)
    return false;
  if (!('first_name' in obj))
    return false;
  if (!('last_name' in obj))
    return false;
  if (!('age' in obj))
    return false;
  return true;
}

// define function that check if
// the obj is of person name and
// other name or not
export function isNameUpdate(obj: any) {
  if (typeof obj !== 'object' || obj === null)
    return false;
  if (!('person_name' in obj))
    return false;
  if (!('after' in obj))
    return false;
  return true;
}

// define function that check if
// the obj is of group name and
// other group name or not
export function isAdd(obj: any) {
  if (typeof obj !== 'object' || obj === null)
    return false;
  if (!('big_group' in obj))
    return false;
  if (!('small_group' in obj))
    return false;
  return true;
}

// define function that check if
// the obj is of person name and
// other group name or not
export function isSearch(obj: any) {
  if (typeof obj !== 'object' || obj === null)
    return false;
  if (!('person_name' in obj))
    return false;
  if (!('group_name' in obj))
    return false;
  return true;
}