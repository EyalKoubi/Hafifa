// imports
import express from "express";
import mongoose from "mongoose";
import { Admins } from "./Models";
import { admin_router } from "./Routers";
import { quiz_router } from "./Routers";
import cors from "cors";
const app = express();
app.use(cors());

// define function for connect
// to the Data Base
export const connectToDb = async () => {
  try {
    await mongoose.connect("mongodb://127.0.0.1/myDB");
    console.log("Connected to MongoDB");
  } catch (error) {
    console.log("Error connecting to MongoDB:");
  }
};

// define function for using
// the routers of the application
const use = () => {
  app.use(express.json());
  app.use("/admins", admin_router);
  app.use("/quizs", quiz_router);
  app.use(function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Methods", "GET,PUT,POST,DELETE");
    res.header("Access-Control-Allow-Headers", "Content-Type");
    next();
  });
  app.use(cors());
};

// define function for create indexes
// for the relations and for aggretion
const indexes = () => {
  Admins.collection.createIndex({ full_name: 1 });
};

// define main function
// for activate the app
const main = () => {
  use();
  connectToDb();
  indexes();

  app.listen(8000, () => console.log(`Server is now listening on port 8000`));
};

// activate the app
main();
