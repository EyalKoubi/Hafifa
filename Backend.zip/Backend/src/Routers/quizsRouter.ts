import { Router } from "express";
import * as contQuiz from "../controllers/quizsController";
import { Quizs } from "../Models";

export const quiz_router = Router();

quiz_router.post("/create", async (req, res) => {
  const body = req.body;
  await contQuiz.create(body, res);
});

quiz_router.get("/isFound", async (req, res) => {
  const question = req.query.question;
  await contQuiz.isFound(question, res);
});

quiz_router.get("/getSingleQuestion", async (req, res) => {
  return await contQuiz.getSQ(req.query.question, res);
});

quiz_router.get("/getQuestions", async (req, res) => {
  await contQuiz.getQ(res);
});

quiz_router.patch("/update/:id", async (req, res) => {
  const ID = req.params.id;
  const body = req.body;
  return await contQuiz.update(ID, body, res);
});

quiz_router.delete("/delete/:id", async (req, res) => {
  await Quizs.findByIdAndDelete(req.params.id);
  return res.send("Item removed successfully");
});
