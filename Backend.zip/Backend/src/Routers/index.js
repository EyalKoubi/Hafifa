"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.mission_router = void 0;
// imports
const missionsRouter_1 = require("./missionsRouter");
Object.defineProperty(exports, "mission_router", { enumerable: true, get: function () { return missionsRouter_1.mission_router; } });
