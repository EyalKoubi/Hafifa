import { Router } from "express";
import * as contAdmin from "../controllers/adminsController";

export const admin_router = Router();

admin_router.post("/create", async (req, res) => {
  const body = req.body;
  await contAdmin.create(body, res);
});

admin_router.post("/isFound", async (req, res) => {
  const body = req.body;
  await contAdmin.isFound(body, res);
});
