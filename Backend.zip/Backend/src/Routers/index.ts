// imports
import { admin_router } from "./adminsRouter";
import { quiz_router } from "./quizsRouter";

// exports
export { admin_router, quiz_router };
