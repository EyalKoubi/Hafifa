import { Admins } from "../Models";

export async function isFound(body: any, res: any) {
  const user = await Admins.findOne({
    user_name: body.user_name,
    password: body.password,
  });
  if (user) return res.send("true");
  return res.send("false");
}

export async function create(body: any, res: any) {
  await Admins.insertMany([body]);
  return res.send("The admin: " + body.full_name + " added successfully!");
}
