import { Quizs } from "../Models";

export async function create(body: any, res: any) {
  await Quizs.insertMany([body]);
  return res.send("The quiz: " + body + " added successfully!");
}
export async function isFound(question: any, res: any) {
  const exists = await Quizs.findOne({ question: question });
  if (exists) return res.send("true");
  return res.send("false");
}
export async function getQ(res: any) {
  const objects = await Quizs.find({});
  return res.send(objects);
}

export async function getSQ(que: any, res: any) {
  const details = await Quizs.findOne({ question: que });
  return res.send(details);
}

export async function update(ID: any, body: any, res: any) {
  const newQuiz = await Quizs.findByIdAndUpdate(ID, body, {
    new: true,
  });
  if (newQuiz) return res.send(newQuiz);
  return res.send({ message: "error" });
}
